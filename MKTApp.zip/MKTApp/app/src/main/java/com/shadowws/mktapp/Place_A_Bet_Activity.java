package com.shadowws.mktapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

public class Place_A_Bet_Activity extends AppCompatActivity {

    Spinner spinner;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_abet);

        // Change top color to white
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        // Remove title
        getSupportActionBar().hide();


        // for spinner property color
        spinner = findViewById(R.id.spinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.number_array)){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textview = (TextView) view.findViewById(android.R.id.text1);
                textview.setTextColor(getResources().getColor(R.color.black));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        EditText agent_num1 = findViewById(R.id.agent_num1);
        EditText agent_num2 = findViewById(R.id.agent_num2);
        EditText agent_num3 = findViewById(R.id.agent_num3);
        EditText agent_num4 = findViewById(R.id.agent_num4);
        EditText agent_num5 = findViewById(R.id.agent_num5);
        EditText agent_num6 = findViewById(R.id.agent_num6);
        EditText agent_num7 = findViewById(R.id.agent_num7);
        EditText agent_num8 = findViewById(R.id.agent_num8);

        agent_num1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 6) {
                    agent_num1.clearFocus();
                    agent_num2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num2.clearFocus();
                    agent_num3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num3.clearFocus();
                    agent_num4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num4.clearFocus();
                    agent_num5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num5.clearFocus();
                    agent_num6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num6.clearFocus();
                    agent_num7.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num7.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num7.clearFocus();
                    agent_num8.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        agent_num8.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 4) {
                    agent_num8.clearFocus();

                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

    }


}